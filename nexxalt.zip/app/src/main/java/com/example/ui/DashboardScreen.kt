package com.example.ui

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.TrackEntity

// Sleek Interface Theme Colors matching the modern Sleek aesthetic
val SlateDarkBg = Color(0xFF1A1C1E)       // Warm dark slate background (bg-[#1A1C1E])
val SlateCardBg = Color(0xFF2F3033)       // Medium gray-slate container (bg-[#2F3033])
val SlateBorder = Color(0xFF44474E)       // Refined border color (border-[#44474E])
val SleekLightBlue = Color(0xFFD1E4FF)    // Highlight ice/sky blue (D1E4FF)
val SleekDeepBlue = Color(0xFF004A77)     // Inner accent / Gradient stop (004A77)
val SleekTextLight = Color(0xFFE2E2E6)    // Soft white text headers (E2E2E6)
val SleekDarkBlueText = Color(0xFF003258) // Dark contrast text for buttons (003258)
val SleekButtonBlue = Color(0xFF0061A4)   // Sleek primary action blue (0061A4)
val SleekPillBg = Color(0xFF3F4759)       // Deep slate-blue pill/tag (3F4759)
val CyberCyan = Color(0xFFD1E4FF)         // Mapped to SleekLightBlue for robust compilation safety across existing code
val CyberPink = Color(0xFFDB2777)         // Primary instagram tag
val SoundwaveYellow = Color(0xFFFBBF24)   // Visualizer yellow
val SoftText = Color(0xFF8E9199)          // Accessible body gray-slate (8E9199)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    // Observables
    val inputUrl by viewModel.inputUrl.collectAsStateWithLifecycle()
    val audioOnly by viewModel.audioOnly.collectAsStateWithLifecycle()
    val customNodeUrl by viewModel.customNodeUrl.collectAsStateWithLifecycle()
    val isDownloading by viewModel.isDownloading.collectAsStateWithLifecycle()
    val downloadStatus by viewModel.downloadStatus.collectAsStateWithLifecycle()
    val downloadProgress by viewModel.downloadProgress.collectAsStateWithLifecycle()

    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val mediaFilter by viewModel.mediaFilter.collectAsStateWithLifecycle()
    val tracks by viewModel.filteredTrackList.collectAsStateWithLifecycle()

    val currentPlayingTrack by viewModel.currentPlayingTrack.collectAsStateWithLifecycle()
    val isPlaying by viewModel.isPlaying.collectAsStateWithLifecycle()
    val playbackDuration by viewModel.playbackDuration.collectAsStateWithLifecycle()
    val playbackPosition by viewModel.playbackPosition.collectAsStateWithLifecycle()
    val uiError by viewModel.uiError.collectAsStateWithLifecycle()

    // Interactive Local States
    var showAdvancedSettings by remember { mutableStateOf(false) }
    var deleteCandidate by remember { mutableStateOf<TrackEntity?>(null) }

    // Display Toast elements for errors
    LaunchedEffect(uiError) {
        uiError?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            viewModel.clearUiError()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(SlateDarkBg)
            .statusBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = if (currentPlayingTrack != null) 140.dp else 16.dp)
        ) {
            // Header Hero Banner matching the sleek Tailwind styling
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Brush.linearGradient(listOf(SleekLightBlue, SleekDeepBlue))),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "N",
                                color = SleekDarkBlueText,
                                fontSize = 21.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.testTag("app_logo_badge")
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "NexxAlt",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = SleekTextLight,
                            fontFamily = FontFamily.SansSerif,
                            letterSpacing = (-0.5).sp
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "High-Quality Media Extractions",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = SleekLightBlue.copy(alpha = 0.85f),
                        letterSpacing = 0.5.sp
                    )
                }

                IconButton(
                    onClick = { showAdvancedSettings = !showAdvancedSettings },
                    modifier = Modifier
                        .size(40.dp)
                        .background(SlateCardBg, CircleShape)
                        .testTag("settings_button")
                ) {
                    Icon(
                        imageVector = if (showAdvancedSettings) Icons.Outlined.SettingsApplications else Icons.Outlined.Settings,
                        contentDescription = "Cobalt custom nodes settings",
                        tint = if (showAdvancedSettings) SleekLightBlue else SleekTextLight
                    )
                }
            }

            // Advanced settings collapse section
            AnimatedVisibility(
                visible = showAdvancedSettings,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = SlateCardBg),
                    border = CardStroke()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Cobalt Engine Node Customization",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "If extraction fails, switch nodes or enter your personal Cobalt node API instance:",
                            fontSize = 11.sp,
                            color = SoftText,
                            lineHeight = 15.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        
                        TextField(
                            value = customNodeUrl,
                            onValueChange = { viewModel.setCustomNodeUrl(it) },
                            singleLine = true,
                            colors = customTextFieldColors(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("node_input_field"),
                            shape = RoundedCornerShape(10.dp),
                            placeholder = { Text("https://api.cobalt.tools", color = SoftText, fontSize = 13.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        
                        // Node candidates fast row picker
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            listOf(
                                "https://api.cobalt.tools" to "Default",
                                "https://co.wuk.sh" to "Mirror 1",
                                "https://cobalt.api.rybofl.com" to "Mirror 2"
                            ).forEach { (url, label) ->
                                InputChip(
                                    selected = customNodeUrl == url,
                                    onClick = { viewModel.setCustomNodeUrl(url) },
                                    label = { Text(label, fontSize = 11.sp) },
                                    colors = InputChipDefaults.inputChipColors(
                                        selectedContainerColor = CyberCyan.copy(alpha = 0.2f),
                                        selectedLabelColor = CyberCyan,
                                        containerColor = SlateDarkBg,
                                        labelColor = Color.White
                                    ),
                                    border = BorderStroke(1.dp, if (customNodeUrl == url) CyberCyan else SlateBorder)
                                )
                            }
                        }
                    }
                }
            }

            // Converter Paste & Download console Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                colors = CardDefaults.cardColors(containerColor = SlateCardBg),
                border = CardStroke(),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Extract Link",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    TextField(
                        value = inputUrl,
                        onValueChange = { viewModel.updateUrl(it) },
                        placeholder = { Text("Paste YouTube or Instagram link here...", color = SoftText, fontSize = 13.sp) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("url_link_input"),
                        leadingIcon = {
                            Icon(imageVector = Icons.Filled.Link, contentDescription = "Link symbol", tint = CyberCyan)
                        },
                        trailingIcon = {
                            Row {
                                if (inputUrl.isNotBlank()) {
                                    IconButton(onClick = { viewModel.updateUrl("") }) {
                                        Icon(imageVector = Icons.Filled.Close, contentDescription = "Clear content", tint = SoftText)
                                    }
                                }
                                IconButton(
                                    onClick = {
                                        clipboardManager.getText()?.text?.let { viewModel.updateUrl(it) }
                                    }
                                ) {
                                    Icon(imageVector = Icons.Filled.ContentPaste, contentDescription = "Paste text", tint = CyberCyan)
                                }
                            }
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Uri,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                keyboardController?.hide()
                                viewModel.startExtraction()
                            }
                        ),
                        colors = customTextFieldColors(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Mode toggler buttons (MP3 versus MP4) matching Tailwind theme chips
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SlateDarkBg, RoundedCornerShape(10.dp))
                            .padding(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (audioOnly) SleekLightBlue else Color.Transparent)
                                .clickable { viewModel.setAudioOnly(true) }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.MusicNote,
                                    contentDescription = "Music conversion",
                                    tint = if (audioOnly) SleekDarkBlueText else Color(0xFFC4C6D0),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Audio MP3",
                                    color = if (audioOnly) SleekDarkBlueText else Color(0xFFC4C6D0),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (!audioOnly) SleekLightBlue else Color.Transparent)
                                .clickable { viewModel.setAudioOnly(false) }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.Videocam,
                                    contentDescription = "Video conversion",
                                    tint = if (!audioOnly) SleekDarkBlueText else Color(0xFFC4C6D0),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Video MP4",
                                    color = if (!audioOnly) SleekDarkBlueText else Color(0xFFC4C6D0),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Execute Conversion Action: Styled with SleekButtonBlue and white text
                    Button(
                        onClick = {
                            keyboardController?.hide()
                            viewModel.startExtraction()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SleekButtonBlue,
                            contentColor = Color.White,
                            disabledContainerColor = SleekButtonBlue.copy(alpha = 0.5f),
                            disabledContentColor = Color.White.copy(alpha = 0.6f)
                        ),
                        enabled = !isDownloading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .shadow(
                                elevation = if (isDownloading) 0.dp else 6.dp,
                                shape = RoundedCornerShape(12.dp),
                                ambientColor = SleekButtonBlue,
                                spotColor = SleekButtonBlue
                            )
                            .testTag("extract_media_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isDownloading) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.5.dp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Connecting Nodes...", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        } else {
                            Icon(
                                imageVector = if (audioOnly) Icons.Filled.Headphones else Icons.Filled.Download,
                                contentDescription = "Conversion launch icon",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (audioOnly) "Convert & Extract MP3" else "Download Offline MP4",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Real-Time Download status indicator
            AnimatedVisibility(
                visible = isDownloading,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = SlateCardBg),
                    border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.35f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Extracting Stream File",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyberCyan
                            )
                            Text(
                                text = if (downloadProgress != null) "${downloadProgress}%" else "Polling...",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(8.dp))

                        if (downloadProgress != null) {
                            val progressFloat = (downloadProgress ?: 0).toFloat() / 100f
                            LinearProgressIndicator(
                                progress = { progressFloat },
                                color = CyberCyan,
                                trackColor = SlateDarkBg,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(CircleShape)
                            )
                        } else {
                            LinearProgressIndicator(
                                color = CyberCyan,
                                trackColor = SlateDarkBg,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(CircleShape)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = downloadStatus,
                            fontSize = 11.sp,
                            color = SoftText,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // LOCAL OFFLINE LIBRARY BODY
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 20.dp)
            ) {
                // Header & Search queries
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Offline Library",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    // Compact counter pill
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = SlateCardBg,
                        border = CardStroke()
                    ) {
                        Text(
                            text = "${tracks.size} Saved",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberCyan,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Inline search bar
                TextField(
                    value = searchQuery,
                    onValueChange = { viewModel.updateSearchQuery(it) },
                    placeholder = { Text("Search your local dynamic files...", color = SoftText, fontSize = 13.sp) },
                    singleLine = true,
                    colors = customTextFieldColors(),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("library_search_bar"),
                    leadingIcon = {
                        Icon(imageVector = Icons.Filled.Search, contentDescription = "Search library icon", tint = SoftText, modifier = Modifier.size(18.dp))
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Library lists filter category segments (All, MP3, MP4)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    listOf(
                        "all" to "All",
                        "audio" to "MP3 Audio",
                        "video" to "MP4 Videos"
                    ).forEach { (field, name) ->
                        val selected = mediaFilter == field
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(30.dp))
                                .background(if (selected) CyberCyan.copy(alpha = 0.15f) else SlateCardBg)
                                .clickable { viewModel.setMediaFilter(field) }
                                .drawBehind {
                                    if (selected) {
                                        drawRect(
                                            color = CyberCyan,
                                            size = size.copy(height = 2.dp.toPx()),
                                            topLeft = androidx.compose.ui.geometry.Offset(0f, size.height - 2.dp.toPx())
                                        )
                                    }
                                }
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = name,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selected) CyberCyan else Color.White
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Library Lazy list viewport
                if (tracks.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(SlateCardBg)
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.QueueMusic,
                                contentDescription = "Library empty status symbol",
                                tint = SoftText,
                                modifier = Modifier
                                    .size(52.dp)
                                    .testTag("empty_library_indicator")
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Your Local Library Is Empty",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (searchQuery.isNotEmpty()) "No results matching yours search tags." else "Enter YouTube/Instagram links above, select download format, and hit convert to extract audio streams here.",
                                fontSize = 11.sp,
                                color = SoftText,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                lineHeight = 16.sp,
                                modifier = Modifier.padding(horizontal = 16.dp)
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .testTag("saved_tracks_scroller")
                    ) {
                        items(tracks, key = { it.id }) { track ->
                            val isPlayingThis = currentPlayingTrack?.id == track.id
                            LibraryTrackRowItem(
                                track = track,
                                isActive = isPlayingThis,
                                isPlaying = isPlaying && isPlayingThis,
                                onPlayTap = { viewModel.playTrack(track) },
                                onShareTap = { viewModel.shareTrackFile(context, track) },
                                onDeleteTap = { deleteCandidate = track }
                            )
                        }
                    }
                }
            }
        }

        // Bottom integrated Dynamic Media Playback Widget sliding console
        AnimatedVisibility(
            visible = currentPlayingTrack != null,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            currentPlayingTrack?.let { track ->
                PlaybackWidget(
                    track = track,
                    isPlaying = isPlaying,
                    currentTimeMs = playbackPosition,
                    durationMs = playbackDuration,
                    onPlayPauseToggle = { viewModel.togglePlayPause() },
                    onCloseTap = { viewModel.stopPlayback() },
                    onSeek = { viewModel.seekTo(it) }
                )
            }
        }

        // Wipe Confirmation modal dialog
        deleteCandidate?.let { track ->
            AlertDialog(
                onDismissRequest = { deleteCandidate = null },
                containerColor = SlateCardBg,
                title = { Text("Wipe Offline Track?", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Text(
                        "Are you sure you want to permanently delete \"${track.title}\" and free up space? This deletes the file from device storage.",
                        color = SoftText,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            viewModel.deleteTrack(track)
                            deleteCandidate = null
                        }
                    ) {
                        Text("Delete Permanent", color = Color.Red, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { deleteCandidate = null }) {
                        Text("Keep File", color = Color.White)
                    }
                },
                modifier = Modifier.testTag("delete_dialog")
            )
        }
    }
}

// Complete library list entry design
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LibraryTrackRowItem(
    track: TrackEntity,
    isActive: Boolean,
    isPlaying: Boolean,
    onPlayTap: () -> Unit,
    onShareTap: () -> Unit,
    onDeleteTap: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = onPlayTap,
                onLongClick = onShareTap
            )
            .testTag("track_row_${track.id}"),
        colors = CardDefaults.cardColors(
            containerColor = if (isActive) SlateCardBg else SlateCardBg.copy(alpha = 0.65f)
        ),
        border = BorderStroke(1.dp, if (isActive) CyberCyan.copy(alpha = 0.5f) else SlateBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Visual circle with media type indicator + brand flag badge
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (isActive) CyberCyan.copy(alpha = 0.15f) else SlateDarkBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (track.mediaType == "audio") Icons.Filled.Audiotrack else Icons.Filled.PlayCircle,
                    contentDescription = "MediaType visual icon",
                    tint = if (isActive) CyberCyan else Color.White.copy(alpha = 0.7f),
                    modifier = Modifier.size(22.dp)
                )

                // Small tiny branding corner indicator badge (red logic for YouTube, pink for Instagram)
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(
                            when (track.sourceType) {
                                "youtube" -> Color.Red
                                "instagram" -> CyberPink
                                else -> CyberCyan
                            }
                        )
                        .align(Alignment.TopEnd)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Body text area: title and details
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = track.title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isActive) CyberCyan else Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                
                Spacer(modifier = Modifier.height(2.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (track.sourceType == "youtube") "YouTube" else "Instagram",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (track.sourceType == "youtube") Color.Red.copy(alpha = 0.8f) else CyberPink.copy(alpha = 0.8f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = formatSize(track.fileSize),
                        fontSize = 10.sp,
                        color = SoftText
                    )
                    if (track.durationMs > 0L) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(imageVector = Icons.Filled.AccessTime, contentDescription = "Length indicator icon", tint = SoftText, modifier = Modifier.size(9.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = formatDuration(track.durationMs),
                            fontSize = 10.sp,
                            color = SoftText
                        )
                    }
                }
            }

            // Sub control tray triggers
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Play Indicator Trigger
                IconButton(onClick = onPlayTap, modifier = Modifier.size(36.dp)) {
                    Icon(
                        imageVector = if (isActive && isPlaying) Icons.Filled.PauseCircle else Icons.Filled.PlayArrow,
                        contentDescription = "Direct play button",
                        tint = if (isActive) CyberCyan else Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Share toggle
                IconButton(onClick = onShareTap, modifier = Modifier.size(36.dp)) {
                    Icon(
                        imageVector = Icons.Filled.Share,
                        contentDescription = "Share file trigger icon",
                        tint = SoftText,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Delete handle
                IconButton(onClick = onDeleteTap, modifier = Modifier.size(36.dp)) {
                    Icon(
                        imageVector = Icons.Filled.Delete,
                        contentDescription = "Wipe file row item",
                        tint = Color.Red.copy(alpha = 0.7f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

// Responsive, gorgeous slider seeking and visualizer panel playing widget at root bottom
@Composable
fun PlaybackWidget(
    track: TrackEntity,
    isPlaying: Boolean,
    currentTimeMs: Long,
    durationMs: Long,
    onPlayPauseToggle: () -> Unit,
    onCloseTap: () -> Unit,
    onSeek: (Long) -> Unit
) {
    // Dynamic sound frequency visualizer bar pulses
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_bars")
    val pulseHeightRatio1 by infiniteTransition.animateFloat(
        initialValue = 0.15f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(animation = tween(420, easing = LinearEasing), repeatMode = RepeatMode.Reverse),
        label = "pulser1"
    )
    val pulseHeightRatio2 by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.75f,
        animationSpec = infiniteRepeatable(animation = tween(310, easing = LinearEasing), repeatMode = RepeatMode.Reverse),
        label = "pulser2"
    )
    val pulseHeightRatio3 by infiniteTransition.animateFloat(
        initialValue = 0.1f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(animation = tween(530, easing = LinearEasing), repeatMode = RepeatMode.Reverse),
        label = "pulser3"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .shadow(16.dp, shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp), ambientColor = CyberCyan, spotColor = CyberCyan)
            .testTag("playback_panel"),
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        colors = CardDefaults.cardColors(containerColor = SlateCardBg),
        border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.35f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            // Track title & visual state indicators
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Pulsing animated Soundwave logo container
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(CyberCyan.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isPlaying) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(2.dp),
                                modifier = Modifier.align(Alignment.Center)
                            ) {
                                Box(modifier = Modifier.width(3.dp).fillMaxHeight(0.5f * pulseHeightRatio1).background(CyberCyan))
                                Box(modifier = Modifier.width(3.dp).fillMaxHeight(0.7f * pulseHeightRatio2).background(CyberCyan))
                                Box(modifier = Modifier.width(3.dp).fillMaxHeight(0.4f * pulseHeightRatio3).background(CyberCyan))
                            }
                        } else {
                            Icon(imageVector = Icons.Filled.Audiotrack, contentDescription = "Sound animation logo idle", tint = CyberCyan, modifier = Modifier.size(16.dp))
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = track.title,
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = if (track.mediaType == "audio") "Offline MP3 Extraction" else "Offline MP4 Video playback",
                            color = CyberCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onPlayPauseToggle) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Filled.PauseCircle else Icons.Filled.PlayCircle,
                            contentDescription = "Floating action pause selection",
                            tint = CyberCyan,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    IconButton(onClick = onCloseTap) {
                        Icon(imageVector = Icons.Filled.Close, contentDescription = "Wipe player container", tint = SoftText)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Seekbar slider tracking
            val endRange = if (durationMs > 0) durationMs.toFloat() else 100f
            val currentPosFloat = currentTimeMs.toFloat().coerceIn(0f, endRange)

            Slider(
                value = currentPosFloat,
                onValueChange = { onSeek(it.toLong()) },
                valueRange = 0f..endRange,
                colors = SliderDefaults.colors(
                    thumbColor = CyberCyan,
                    activeTrackColor = CyberCyan,
                    inactiveTrackColor = SlateDarkBg
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(20.dp)
                    .testTag("playback_seekbar")
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Floating time marks indicators
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = formatDuration(currentTimeMs), fontSize = 11.sp, color = SoftText)
                Text(text = formatDuration(durationMs), fontSize = 11.sp, color = SoftText)
            }
        }
    }
}

// Utility styling borders
@Composable
fun CardStroke() = BorderStroke(1.dp, SlateBorder)

// Form customizable text color schema
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun customTextFieldColors() = TextFieldDefaults.colors(
    focusedContainerColor = SlateDarkBg,
    unfocusedContainerColor = SlateDarkBg,
    disabledContainerColor = SlateDarkBg,
    focusedIndicatorColor = CyberCyan,
    unfocusedIndicatorColor = SlateBorder,
    disabledIndicatorColor = Color.Transparent,
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    focusedLabelColor = CyberCyan,
    unfocusedLabelColor = SoftText
)

// Unit utility converter helper formulas
fun formatSize(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = listOf("B", "KB", "MB", "GB")
    var value = bytes.toDouble()
    var index = 0
    while (value >= 1024 && index < units.size - 1) {
        value /= 1024
        index++
    }
    return String.format("%.1f %s", value, units[index])
}

fun formatDuration(ms: Long): String {
    if (ms <= 0) return "00:00"
    val totalSec = ms / 1000
    val min = totalSec / 60
    val sec = totalSec % 60
    return String.format("%02d:%02d", min, sec)
}
