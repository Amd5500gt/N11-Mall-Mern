package com.example.ui

import android.app.Application
import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import android.util.Log
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.TrackEntity
import com.example.network.CobaltDownloader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val downloader = CobaltDownloader(application)

    // Link extraction inputs
    private val _inputUrl = MutableStateFlow("")
    val inputUrl = _inputUrl.asStateFlow()

    private val _audioOnly = MutableStateFlow(true)
    val audioOnly = _audioOnly.asStateFlow()

    private val _customNodeUrl = MutableStateFlow("https://api.cobalt.tools")
    val customNodeUrl = _customNodeUrl.asStateFlow()

    // Activity state
    private val _isDownloading = MutableStateFlow(false)
    val isDownloading = _isDownloading.asStateFlow()

    val downloadStatus = downloader.downloadStatus
    val downloadProgress = downloader.downloadProgress

    // Local library lists filtering
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _mediaFilter = MutableStateFlow("all") // "all", "audio", "video"
    val mediaFilter = _mediaFilter.asStateFlow()

    val filteredTrackList: StateFlow<List<TrackEntity>> = db.trackDao().getAllTracks()
        .combine(_searchQuery) { tracks, query ->
            if (query.isBlank()) tracks else tracks.filter { it.title.contains(query, ignoreCase = true) }
        }
        .combine(_mediaFilter) { tracks, filter ->
            if (filter == "all") tracks else tracks.filter { it.mediaType == filter }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Player media state values
    private var mediaPlayer: MediaPlayer? = null
    private var progressJob: Job? = null

    private val _currentPlayingTrack = MutableStateFlow<TrackEntity?>(null)
    val currentPlayingTrack = _currentPlayingTrack.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying = _isPlaying.asStateFlow()

    private val _playbackDuration = MutableStateFlow(0L)
    val playbackDuration = _playbackDuration.asStateFlow()

    private val _playbackPosition = MutableStateFlow(0L)
    val playbackPosition = _playbackPosition.asStateFlow()

    private val _uiError = MutableStateFlow<String?>(null)
    val uiError = _uiError.asStateFlow()

    // Input handlers
    fun updateUrl(url: String) {
        _inputUrl.value = url
    }

    fun setAudioOnly(audio: Boolean) {
        _audioOnly.value = audio
    }

    fun setCustomNodeUrl(node: String) {
        _customNodeUrl.value = node
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setMediaFilter(filter: String) {
        _mediaFilter.value = filter
    }

    fun clearUiError() {
        _uiError.value = null
    }

    // Call Cobalt service download and map results
    fun startExtraction() {
        val targetUrl = _inputUrl.value.trim()
        if (targetUrl.isBlank()) {
            _uiError.value = "Please input a valid YouTube or Instagram link."
            return
        }

        viewModelScope.launch {
            try {
                _isDownloading.value = true
                val result = downloader.downloadMedia(
                    videoUrl = targetUrl,
                    audioOnly = _audioOnly.value,
                    customBaseUrl = _customNodeUrl.value
                )

                if (result.isSuccess) {
                    _inputUrl.value = "" // clear inputs
                } else {
                    _uiError.value = result.exceptionOrNull()?.localizedMessage ?: "Failed linking media"
                }
            } catch (e: Exception) {
                _uiError.value = "Extraction issue: ${e.localizedMessage}"
            } finally {
                _isDownloading.value = false
            }
        }
    }

    // Controls for built-in music player
    fun playTrack(track: TrackEntity) {
        val file = File(track.localUri)
        if (!file.exists()) {
            _uiError.value = "File not found locally. It might have been deleted."
            return
        }

        viewModelScope.launch {
            try {
                stopPlayback()

                mediaPlayer = MediaPlayer().apply {
                    setDataSource(track.localUri)
                    prepare()
                    start()
                }

                _currentPlayingTrack.value = track
                _isPlaying.value = true
                _playbackDuration.value = mediaPlayer?.duration?.toLong() ?: 0L

                // Update database state with exact play duration
                if (track.durationMs == 0L && (mediaPlayer?.duration ?: 0) > 0) {
                    launch(Dispatchers.IO) {
                        db.trackDao().insertTrack(track.copy(durationMs = mediaPlayer?.duration?.toLong() ?: 0L))
                    }
                }

                startProgressTracker()

                mediaPlayer?.setOnCompletionListener {
                    stopPlayback()
                }
            } catch (e: Exception) {
                Log.e("MainViewModel", "Playback error", e)
                _uiError.value = "Unsupported audio format or damaged stream file."
            }
        }
    }

    fun togglePlayPause() {
        mediaPlayer?.let { player ->
            try {
                if (player.isPlaying) {
                    player.pause()
                    _isPlaying.value = false
                } else {
                    player.start()
                    _isPlaying.value = true
                }
            } catch (e: Exception) {
                Log.e("MainViewModel", "Toggle play fail", e)
            }
        }
    }

    fun seekTo(positionMs: Long) {
        mediaPlayer?.let { player ->
            try {
                player.seekTo(positionMs.toInt())
                _playbackPosition.value = positionMs
            } catch (e: Exception) {
                Log.e("MainViewModel", "Seeking error", e)
            }
        }
    }

    fun stopPlayback() {
        progressJob?.cancel()
        mediaPlayer?.let { player ->
            try {
                if (player.isPlaying) {
                    player.stop()
                }
            } catch (e: Exception) { }
            player.release()
        }
        mediaPlayer = null
        _isPlaying.value = false
        _playbackPosition.value = 0L
    }

    private fun startProgressTracker() {
        progressJob?.cancel()
        progressJob = viewModelScope.launch {
            while (true) {
                mediaPlayer?.let { player ->
                    try {
                        if (player.isPlaying) {
                            _playbackPosition.value = player.currentPosition.toLong()
                        }
                    } catch (e: Exception) { }
                }
                delay(200)
            }
        }
    }

    // Share extracted file across external messaging apps
    fun shareTrackFile(context: Context, track: TrackEntity) {
        try {
            val file = File(track.localUri)
            if (!file.exists()) {
                _uiError.value = "The downloaded file could not be parsed."
                return
            }
            val authority = "com.aistudio.nexxalt.downld.zxtqya.fileprovider"
            val fileUri: Uri = FileProvider.getUriForFile(context, authority, file)

            val shareIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = if (track.mediaType == "audio") "audio/*" else "video/*"
                putExtra(android.content.Intent.EXTRA_STREAM, fileUri)
                putExtra(android.content.Intent.EXTRA_SUBJECT, track.title)
                putExtra(android.content.Intent.EXTRA_TEXT, "Listen offline to \"${track.title}\" extracted with NexxAlt!")
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(android.content.Intent.createChooser(shareIntent, "Share Track"))
        } catch (e: Exception) {
            Log.e("MainViewModel", "Sharing failure", e)
            _uiError.value = "Sharing could not initialize: ${e.localizedMessage}"
        }
    }

    // Safely remove file on memory and from DB list
    fun deleteTrack(track: TrackEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                if (_currentPlayingTrack.value?.id == track.id) {
                    launch(Dispatchers.Main) {
                        stopPlayback()
                        _currentPlayingTrack.value = null
                    }
                }

                db.trackDao().deleteTrack(track.id)

                val file = File(track.localUri)
                if (file.exists()) {
                    file.delete()
                }
            } catch (e: Exception) {
                Log.e("MainViewModel", "Wipe media fails", e)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        stopPlayback()
    }
}
