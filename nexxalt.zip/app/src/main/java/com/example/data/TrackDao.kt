package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TrackDao {
    @Query("SELECT * FROM tracks ORDER BY timestamp DESC")
    fun getAllTracks(): Flow<List<TrackEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrack(track: TrackEntity): Long

    @Query("DELETE FROM tracks WHERE id = :id")
    suspend fun deleteTrack(id: Int): Int

    @Query("SELECT * FROM tracks WHERE sourceUrl = :url LIMIT 1")
    suspend fun getTrackByUrl(url: String): TrackEntity?
}
