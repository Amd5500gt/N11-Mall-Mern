package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tracks")
data class TrackEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val sourceUrl: String,
    val localUri: String,     // Absolute path of the downloaded file
    val durationMs: Long = 0,
    val fileSize: Long = 0,
    val sourceType: String,   // "youtube" or "instagram"
    val mediaType: String,    // "audio" (for mp3) or "video" (for mp4)
    val timestamp: Long = System.currentTimeMillis()
)
