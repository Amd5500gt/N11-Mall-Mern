package com.example.network

import android.content.Context
import android.os.Environment
import android.util.Log
import com.example.data.AppDatabase
import com.example.data.TrackEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

class CobaltDownloader(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val database = AppDatabase.getDatabase(context)

    // Observable downloader statuses
    val downloadProgress = MutableStateFlow<Int?>(null)
    val downloadStatus = MutableStateFlow<String>("")

    suspend fun downloadMedia(
        videoUrl: String,
        audioOnly: Boolean,
        customBaseUrl: String? = null
    ): Result<TrackEntity> = withContext(Dispatchers.IO) {
        try {
            downloadProgress.value = null
            downloadStatus.value = "Initiating extraction request..."

            val rawBase = if (!customBaseUrl.isNullOrBlank()) {
                customBaseUrl.trim()
            } else {
                "https://api.cobalt.tools"
            }
            val baseUrl = rawBase.removeSuffix("/")

            val requestBodyJson = JSONObject().apply {
                put("url", videoUrl)
                if (audioOnly) {
                    put("downloadMode", "audio")
                    put("audioFormat", "mp3")
                    put("isAudioOnly", true)
                } else {
                    put("downloadMode", "video")
                    put("videoQuality", "720")
                    put("isAudioOnly", false)
                }
            }

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val request = Request.Builder()
                .url(baseUrl)
                .post(requestBodyJson.toString().toRequestBody(mediaType))
                .header("Accept", "application/json")
                .header("Content-Type", "application/json")
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                val errMsg = try {
                    val root = JSONObject(responseBody)
                    if (root.has("error")) {
                        val errObj = root.get("error")
                        if (errObj is JSONObject) {
                            errObj.optString("text", "Server conversion error")
                        } else {
                            errObj.toString()
                        }
                    } else {
                        "Server error code: ${response.code}"
                    }
                } catch (e: Exception) {
                    "API node responded with error ${response.code}"
                }
                return@withContext Result.failure(Exception(errMsg))
            }

            val responseJson = JSONObject(responseBody)
            val status = responseJson.optString("status", "")

            if (status == "error") {
                val errObj = responseJson.optJSONObject("error")
                val text = errObj?.optString("text") ?: "API connection rejected."
                return@withContext Result.failure(Exception(text))
            }

            val downloadUrl = responseJson.optString("url", "")
            if (downloadUrl.isBlank()) {
                // Check for picker stream as fallback
                val picker = responseJson.optJSONArray("picker")
                if (picker != null && picker.length() > 0) {
                    val firstItem = picker.getJSONObject(0)
                    val pickerUrl = firstItem.optString("url", "")
                    if (pickerUrl.isNotBlank()) {
                        // resolve picker Url
                        return@withContext proceedWithFileDownload(pickerUrl, firstItem.optString("type", "audio") == "audio" || audioOnly, videoUrl)
                    }
                }
                return@withContext Result.failure(Exception("No download stream URL resolved from converter."))
            }

            return@withContext proceedWithDownload(downloadUrl, audioOnly, videoUrl, responseJson.optString("filename", ""))

        } catch (e: Exception) {
            Log.e("CobaltDownloader", "Exception downloading", e)
            downloadStatus.value = "Error: ${e.localizedMessage ?: "Unknown failure"}"
            downloadProgress.value = null
            Result.failure(e)
        }
    }

    private suspend fun proceedWithFileDownload(downloadUrl: String, audioOnly: Boolean, sourceUrl: String): Result<TrackEntity> {
        return proceedWithDownload(downloadUrl, audioOnly, sourceUrl, "")
    }

    private suspend fun proceedWithDownload(
        downloadUrl: String,
        audioOnly: Boolean,
        videoUrl: String,
        providedFilename: String
    ): Result<TrackEntity> {
        downloadStatus.value = "Retrieving media file stream..."
        downloadProgress.value = 0

        val fileRequest = Request.Builder()
            .url(downloadUrl)
            .build()

        val fileResponse = client.newCall(fileRequest).execute()
        if (!fileResponse.isSuccessful) {
            return Result.failure(Exception("File streaming network error ${fileResponse.code}"))
        }

        val fileResponseBody = fileResponse.body ?: return Result.failure(Exception("Empty download body received."))
        val totalBytes = fileResponseBody.contentLength()
        val inputStream = fileResponseBody.byteStream()

        var filename = providedFilename
        if (filename.isBlank()) {
            filename = if (audioOnly) {
                "NexxAlt_Audio_${System.currentTimeMillis()}.mp3"
            } else {
                "NexxAlt_Video_${System.currentTimeMillis()}.mp4"
            }
        }

        val outputFolder = if (audioOnly) {
            context.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: context.filesDir
        } else {
            context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: context.filesDir
        }

        if (!outputFolder.exists()) {
            outputFolder.mkdirs()
        }

        val localFile = File(outputFolder, filename)
        val outputStream = FileOutputStream(localFile)

        val buffer = ByteArray(16384)
        var bytesRead: Int
        var totalRead: Long = 0

        while (inputStream.read(buffer).also { bytesRead = it } != -1) {
            outputStream.write(buffer, 0, bytesRead)
            totalRead += bytesRead
            if (totalBytes > 0) {
                val progress = (totalRead * 100 / totalBytes).toInt()
                downloadProgress.value = progress
                downloadStatus.value = "Streaming: $progress%"
            } else {
                val progressKb = totalRead / 1024
                downloadStatus.value = "Streaming: ${progressKb} KB"
            }
        }

        outputStream.flush()
        outputStream.close()
        inputStream.close()

        downloadStatus.value = "Registering offline file..."
        downloadProgress.value = 100

        val lowUrl = videoUrl.lowercase()
        val sourceType = when {
            lowUrl.contains("youtube") || lowUrl.contains("youtu.be") -> "youtube"
            lowUrl.contains("instagram") -> "instagram"
            else -> "other"
        }

        val mediaTypeField = if (audioOnly) "audio" else "video"
        var displayTitle = filename
        if (displayTitle.endsWith(".mp3")) displayTitle = displayTitle.removeSuffix(".mp3")
        if (displayTitle.endsWith(".mp4")) displayTitle = displayTitle.removeSuffix(".mp4")
        
        // Clean up common visual clutter from titles
        displayTitle = displayTitle
            .replace("_", " ")
            .replace("-", " ")
            .replace("y2mate.com", "")
            .replace("cobalt", "")
            .trim()

        val track = TrackEntity(
            title = displayTitle,
            sourceUrl = videoUrl,
            localUri = localFile.absolutePath,
            durationMs = 0L, 
            fileSize = totalRead,
            sourceType = sourceType,
            mediaType = mediaTypeField
        )

        // Run blockingly/synchronously on this background worker thread
        val db = AppDatabase.getDatabase(context)
        val insertedId = db.trackDao().insertTrack(track)
        val finalTrack = track.copy(id = insertedId.toInt())

        downloadStatus.value = "Downloaded successfully!"
        downloadProgress.value = null

        return Result.success(finalTrack)
    }
}
